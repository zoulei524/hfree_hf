package com.insigma.business.components.hyfield;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.usertype.DynamicParameterizedType;
import org.hibernate.usertype.UserType;
import org.springframework.jdbc.core.JdbcTemplate;

import com.insigma.business.QGGWY.QGGWY_PUB001.QGGWY_PUB001_0004.enums.ECODE;
import com.insigma.business.util.EhCacheUtil;

/**
 * 2024年1月16日10:05:02 zoulei
 * @see HYField
 * hibernate实体的转换
 */
public class HYfieldType implements UserType, DynamicParameterizedType{
	
	private static final int[] SQL_TYPES={Types.VARCHAR}; 
	
	private String codetype;
	private String p;
	private String type;
	
	@Override
	public void setParameterValues(Properties parameters) {
		this.codetype = parameters.getProperty("codetype");
		this.p = parameters.getProperty("p");
		this.type = parameters.getProperty("type");
	}
	
	@Override
	public Object assemble(Serializable serializable, Object obj)
			throws HibernateException {
		return serializable;
	}

	@Override
	public Object deepCopy(Object obj) throws HibernateException {
		return obj; 
	}

	@Override
	public Serializable disassemble(Object obj) throws HibernateException {
		return (Serializable) obj;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		if(x==y){  
            return true;  
        }else if(x==null||y==null){  
            return false;  
        }else {  
            return x.equals(y);  
        }  
	}

	@Override
	public int hashCode(Object obj) throws HibernateException {
		return obj.hashCode();
	}

	@Override
	public boolean isMutable() {
		return false;
	}

	@Override
	public Object replace(Object obj, Object obj1, Object obj2)
			throws HibernateException {
		return obj;
	}

	@Override
	public Class returnedClass() {
		return HYField.class;
	}

	@Override
	public int[] sqlTypes() {
		return SQL_TYPES;
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String[] names, SharedSessionContractImplementor session, Object owner)
			throws HibernateException, SQLException {
		
		if(rs.wasNull()){  
            return new HYField(codetype, p);  
        }else{  
        	String data = rs.getString(names[0]);
            HYField hyField = new HYField(codetype, p);
            if(StringUtils.isEmpty(data)){
            	return hyField;
            }
            
            //2024年1月18日17:32:55  下拉框或弹出框， 或者未定义类型按照代码转换赋值
            if(SELECT.equals(this.type)||POPWIN.equals(this.type)||"".equals(this.type)||this.type==null) {
            	hyField.setKey(data);
            	hyField.setKeyList(Arrays.asList(data.split(",")));
            	if(hyField.getKeyList().size()==1) {
            		String v = this.getCodeName(codetype, data, "");
                    hyField.setValue(v);
            	}else if(hyField.getKeyList().size()>1) {
            		StringBuilder sb = new StringBuilder();
            		hyField.getKeyList().forEach(k->{
            			String v = this.getCodeName(codetype, k, "");
            			sb.append(v+"，");
            		});
            		sb.deleteCharAt(sb.length()-1);
            		hyField.setValue(sb.toString());
            	}
            	
            	
                
            }else if(DATE.equals(this.type)){//日期
            	hyField.setKey(data);
                String v = data;
                hyField.setValue(v);
                v = v.replace(".", "");
				if(v.length()>=6) {
					hyField.setTime(v.substring(0,4)+"."+v.substring(4,6));
				}else {
					hyField.setTime("");
				}
    		}
            return hyField;  
        }  
	}
	
	/**
	 * 通过code_type及code_value获取code_name、code_name2、code_name3
	 *
	 * 样例: SysCodeUtil.getCodeName("ZB01", "110000", "3");
	 */
	@SuppressWarnings("unchecked")
	public  String getCodeName(String codetype,String codevalue, String codeNameNum) {
		if(codevalue == null || "".equals(codevalue)){
			return  "";
		}
		if(codetype == null || "".equals(codetype)){
			return  codevalue;
		}
		
		
		
		String codetypeNum = "".equals(codeNameNum) ? codetype : codetype + "_" + codeNameNum;
		HashMap<String,String> hashmap=(HashMap<String,String>)EhCacheUtil.getObjectInCache(codetypeNum+ECODE.SELECT.getCode());
		if(hashmap!=null) {
			return hashmap.get(codevalue);
		}else {
			String sql="select code_name from code_value where code_type='"+codetype+"' and code_value='"+codevalue+"' and CODE_STATUS = '1'";
			JdbcTemplate jdbcTemplate = (JdbcTemplate)(AppContext.applicationContext).getBean("jdbcTemplate");
			List<Map<String, Object>> codeDetail = jdbcTemplate.queryForList(sql);
			if (codeDetail != null && codeDetail.size() > 0) {
				Map<String, Object> codes = codeDetail.get(0);
				return codes.get("code_name").toString();
			}else {
				return "";
			}
		}
	}

	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index, SharedSessionContractImplementor session)
			throws HibernateException, SQLException {
		if(value==null){  
			st.setNull(index, Types.VARCHAR);  
        }else {  
        	HYField hyField = (HYField) value;
        	String k = hyField.getKey();
        	if(k==null || "".equals(k)) {
        		k = hyField.getValue();
        	}
        	st.setString(index, k);  
        }
		
	}

	/**
	 * 下拉框
	 */
	public final static String SELECT = "1";
	/**
	 * 弹出框
	 */
	public final static String POPWIN = "2";
	/**
	 * 日期6位点2位
	 */
	public final static String DATE = "3";
	
}