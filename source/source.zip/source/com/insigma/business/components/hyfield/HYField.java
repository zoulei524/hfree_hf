package com.insigma.business.components.hyfield;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import lombok.Data;

/**
 * 字段 这种字段结构主要针对代码字段，通过MapToHYDtoUtil.java将Map<String, Object>类型转成对应的dto
 * hibernate方式获取：
 * 实体类对象上添加注解如
 *  @Type(type ="com.insigma.business.components.hyfield.HYfieldType", 
 * 		parameters = { @Parameter(name ="codetype", value ="GB8561"), @Parameter(name ="p", value ="E")})
 * 2023年10月26日11:08:56 zoulei
 * 
 * 2024年1月19日11:15:49
 * 加上时间显示4位点2位
 */
@Data
public class HYField  implements Serializable, Comparable<HYField>, Cloneable{
	
	@Override
	public HYField clone() throws CloneNotSupportedException {
		return (HYField) super.clone();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**值*/
	private String value = "";
	/**若有代码，就有代码值，没有就为空*/
	private String key;
	private List<String> keyList;//多选
	/**R—必填，E—可编辑，H—隐藏，D—不可编辑, E,R—编辑可变为必填*/
	private String p = "E";
	
	/**代码类别*/
	private String codetype;
	
	/**如果是时间显示4位点2位*/
	private String time = "";

	public HYField() {
	}
	
	public HYField(String codetype) {
		this.codetype = codetype;
	}
	
	public HYField(String codetype, String p) {
		this.codetype = codetype;
		if(p!=null&&!"".equals(p))
			this.p = p;
	}

	@Override
	public String toString() {
		//codetype 为空的是时间类型，直接返回value
		if(this.codetype!=null && !"".equals(this.codetype)) {
			if(this.key!=null && !"".equals(this.key)) {
				return this.key;
			}else {
				return this.value;
			}
		}
		return this.value;
	}

	//如果是时间 可以做比较，或者直接比较代码
	@Override
	public int compareTo(HYField o) {
		if(o==null) {
			return 1;
		}
		String thisv = this.toString();
		String compv = o.toString();
		return thisv.compareTo(compv);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HYField other = (HYField) obj;
		return Objects.equals(codetype, other.codetype) && Objects.equals(key, other.key)
				&& Objects.equals(keyList, other.keyList) && Objects.equals(p, other.p)
				&& Objects.equals(time, other.time) && Objects.equals(value, other.value);
	}

	@Override
	public int hashCode() {
		return Objects.hash(codetype, key, keyList, p, time, value);
	}
	
	
	
	
}
